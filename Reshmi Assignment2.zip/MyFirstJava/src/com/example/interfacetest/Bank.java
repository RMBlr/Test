package com.example.interfacetest;

public interface Bank {
	public double calculateinterest(double amount, int year);

	// public double calculateTotalAmount(double amount, int year, double rate);

}
